#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#define max 100000
struct node{
	int data;
	int deg;
	struct node *p;
	struct node *sib;
	struct node *child;
};

struct queue{
	struct node *now;
	struct queue *next;
};

typedef struct queue queue;
typedef struct node node;

queue *q=0;

void push(node *data) {
	queue *newnode=(queue *)calloc(1,sizeof(queue));
	newnode->now=data;
	newnode->next=0;
	if(q==0) {
		q=newnode;
		return ;
	}
	queue *temp=q;
	while(temp->next!=0) {
		temp=temp->next;
	}
	temp->next=newnode;
}

void pop() {
	if(q==0) {
		return ;
	}
	queue *temp=q;
	q=q->next;
	free(temp);
}


node* createnode(int k) {
	node *newnode=(node *)calloc(1,sizeof(node));
	newnode->deg=0;
	newnode->data=k;
	newnode->sib=0;
	newnode->child=0;
	newnode->p=0;
	return newnode;
}


node* unionofheaps(node *h1,node *h2) {
	node *h;
	node *temp;
	if(h1==0)
	return h2;
	if(h2==0)
	return h1;
	if(h1->deg<=h2->deg) {
		h=h1;
		h1=h1->sib;
	}
	else {
		h=h2;
		h2=h2->sib;
	}
	temp=h;
	while(h1!=0&&h2!=0) {
		if(h1->deg<=h2->deg) {
			temp->sib=h1;
			temp=h1;
			h1=h1->sib;
		}
		else {
			temp->sib=h2;
			temp=h2;
			h2=h2->sib;
		}
	}
	if(h1!=0) {
		temp->sib=h1;
	}
	if(h2!=0) {
		temp->sib=h2;
	}
	return h;
}

node* binomiallink(node *x,node *y) {
	y->p=x;
	y->sib=x->child;
	x->child=y;
	x->deg++;
	return x;
}

node* correcting(node *h) {
	node *x=0;
	node *p_x=0;
	node *n_x=0;
	if(h==0||h->sib==0)
	return h;
	x=h;
	n_x=x->sib;
	while(n_x!=0) {
		if(x->deg!=n_x->deg||(n_x->sib!=0&&x->deg==n_x->sib->deg)) {
			p_x=x;
			x=n_x;
			n_x=n_x->sib;
		}
		else {
			if(x->data<=n_x->data) {
				x->sib=n_x->sib;
				binomiallink(x,n_x);
			}
			else {
				if(p_x==0) {
					h=n_x;
				}
				else {
					p_x->sib=n_x;
				}
				binomiallink(n_x,x);
				x=n_x;
			}
			n_x=x->sib;
		}
	}
	return h;
}

node* insert(node *h,int k) {
	node *temp=createnode(k);
	h=unionofheaps(h,temp);
	return correcting(h);
}
node* reverselist(node *root) {
	node *p_x=0,*n_x=0,*x=0;
	if(root==0)
	return x;
	x=root;
	x->p=0;
	while(x!=0) {
		x->p=0;
		n_x=x->sib;
		x->sib=p_x;
		p_x=x;
		x=n_x;
	}
	return p_x;
}
node* extractmin(node *h) {

	node *temp1=0,*temp2=0;
	if(h==0)
	return temp1;
	node *x=h;
	node *p_x=0;
	temp1=x;
	int min=h->data;
	while(x!=0) {
		if(x->data<min) {
			min=x->data;
			temp1=x;
			temp2=p_x;
		}
		p_x=x;
		x=x->sib;
	}
	//printf("%d\n",min);
	if(temp2==0) {
		h=temp1->sib;
	}
	else {
		temp2->sib=temp1->sib;
	}
	node *h2=reverselist(temp1->child);
	h=unionofheaps(h,h2);
	return correcting(h);
}


node* findnode(node* root, int k) {
    if(root==0)
    return root;
    node *p=0;
    if(root->data==k)
    p=root;
    while(root&&p==0) {
    	if(root->data==k&&p==0) {
    		p=root;
		}
		if(root->child&&p==0) {
			p=findnode(root->child,k);
		} 
		root=root->sib;
	}
	return p;
}

node* decreasekey(node *h,int x,int k) {

	if(h==0) {
		return h;
	}
	node *p=findnode(h,x);

	p->data-=k;
	node *p_pt=p->p;
	while(p_pt!=0&&p_pt->data>p->data) {
		int temp=p->data;
		p->data=p_pt->data;
		p_pt->data=temp;
		p=p_pt;
		p_pt=p->p;
	}

	return h;
}

node* deletekey(node *h,int k) {
	if(h==0){
		return h;
	}
	h=decreasekey(h,k,max);
	h=extractmin(h);
	return h;
}

//void traversetree(node * root)
//{
//    if (root == NULL)
//        return;
//        
//        
//        traversetree(root->sib);
//        
//        node *temp=root;
//        node *temp2;
//    while (root)
//    {
//        printf("%d ",root->data);
//        root=root->sib;
//        if(root==0) {
//        	root=temp->child;
//        	temp=root->p->sib;
//		}
//    }
//    treversetree(temp);
//}

void leveltraversal(node *root) {
	if(root==0)
	return ;
	push(root);
	while(q!=0) {
		printf("%d ",q->now->data);
		node *temp=q->now->child;
		while(temp!=0) {
			push(temp);
			temp=temp->sib;
		}
		pop();
	}
}

int DISPLAY(struct node* H) {
    struct node* p;
    if (H == NULL) {
        return 0;
    }
    p = H;
    while (p != NULL) {
        leveltraversal(p);
        p = p->sib;
    }
    printf("\n");
}

int minvalue(node *root) {
	if(root==0)
	return 0;
	int min=root->data;
	while(root) {
		if(root->data<min) {
			min=root->data;
		}
		root=root->sib;
	}
	return min;
}

int main() {
	int j,k,i,x;
	node *h=0;
	char c;
	while(1) {
		scanf("%c",&c);
		switch(c) {
			case 'i':
				scanf("%d",&k);
				h=insert(h,k);
				break;
			case 'p':
				DISPLAY(h);
				//leveltraversal(h);
				//printf("\n");
				break;
			case 'x':
				i=minvalue(h);
				printf("%d\n",i);
				h=extractmin(h);
				break;
			case 'f':
				scanf("%d",&k);
				node *temp=findnode(h,k);
				if(temp==0)
				printf("FALSE\n");
				else {
					printf("%d\n",temp->data);
				}
				break;
			case 'r':
				scanf("%d %d",&x,&k);
				temp=findnode(h,x);
				if(x>=k&&temp!=0) {
					h=decreasekey(h,x,k);
					printf("%d\n",x-k);
				}
				else
				printf("-1\n");
				break;
			case 'd':
				scanf("%d",&k);
				temp=findnode(h,k);
				if(temp==0) {
					printf("-1\n");
				}
				else {
					h=deletekey(h,k);
					printf("%d\n",k);
				} 
				break;
			case 'm':
				i=minvalue(h);
				printf("%d\n",i);
				break;
			case 'e':
				return 0;
		}
	}
	
	return 0;
}


