#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#define max 100000

struct node{
	int data;
	char c;
	struct node *left;
	struct node *right;
	struct node *pt;
};

typedef struct node node;

node* createnode(int k) {
	node *newnode=(node *)calloc(1,sizeof(node));
	newnode->data=k;
	newnode->c='R';
	newnode->left=0;
	newnode->right=0;
	newnode->pt=0;
	return newnode;
}

node* bstinsert(node *root,node *newnode) {
	if(root==0) {
		return newnode;
	} 
	if(root->data<newnode->data) {
		root->right=bstinsert(root->right,newnode);
		root->right->pt=root;
	}
	else {
		root->left=bstinsert(root->left,newnode);
		root->left->pt=root;
	}
	return root;
}

node* leftrotate(node *x) {
	node *y=x->right;
	node *temp=y->left;
	x->right=temp;
	y->left=x;
	y->pt=x->pt;
	if(temp)
	temp->pt=x;
	if(x->pt==0) {
		y->pt=0;
		x->pt=y;
		return y;
	}
	else if(x==x->pt->left) {
		x->pt->left=y;
	}
	else {
		x->pt->right=y;
	}
	x->pt=y;
	return y;
}
node* rightrotate(node *x) {
	node *y=x->left;
	node *temp=y->right;
	x->left=temp;
	y->right=x;
	if(temp!=0)
	x->left->pt=x;
	y->pt=x->pt;
	if(x->pt==0) {
		x->pt=y;
		return y;
	}
	else if(x==x->pt->left) {
		x->pt->left=y;
	}
	else {
		x->pt->right=y;
	}
	x->pt=y;
	return y;
}

/*node* bstinsert(node *root,node *newnode) {
	if(root==0) {
		return newnode;
	} 
	if(root->data<newnode->data) {
		root->right=bstinsert(root->right,newnode);
		root->right->pt=root;
		if(root->right!=0&&root->right->c=='B') {
			return root;
		}
		else if((root->right->left!=0&&root->right->c=='R')||(root->right->right!=0&&root->right->right->c=='R')) {
			if(root->left!=0&&root->left->c=='R') {
				root->left->c='B';
				root->right->c='B';
				root->c='R';
				return root;
			}
			else if(root->left==0||root->left->c=='B') {
				if(root->right->left!=0&&root->right->left->c=='R') {
					root->right=rightrotate(root->right);
				}
				if(root->right->right!=0&&root->right->right->c=='R') {
				root=leftrotate(root);
				root->c='B';
				root->left->c='R';
				}
				return root;
			}
		}
	}
	else {
		root->left=bstinsert(root->left,newnode);
		root->left->pt=root;
		if(root->left->c=='B') {
			return root;
		}
		else if((root->left->left!=0&&root->left->left->c=='R')||(root->left->right!=0&&root->left->right->c=='R')) {
			if(root->right!=0&&root->right->c=='R') {
				root->right->c='B';
				root->left->c='B';
				root->c='R';
				return root;
			}
			else if(root->right==0||root->right->c=='B') {
				if(root->left->right!=0&&root->left->right->c=='R') {
					root->left=leftrotate(root->left);
				}
				if(root->left->left!=0&&root->left->left->c=='R') {
				root=rightrotate(root);
				root->c='B';
				root->right->c='R';
				}
				return root;
			}
		}
	}
	return root;
}*/

node* correcting(node *root,node *p) {
	node *pt_p=0;
	node *gpt_p=0;
	node *u_p=0;
	while((p!=root)&&(p->c=='R')&&(p->pt->c=='R')) {
		pt_p=p->pt;
		gpt_p=p->pt->pt;
		if(pt_p==gpt_p->left) {
			u_p=gpt_p->right;
			if(u_p!=0&&u_p->c=='R') {
				pt_p->c='B';
				u_p->c='B';
				gpt_p->c='R';
				p=gpt_p;
			}
			else {
				if(pt_p->left==p) {
					char ctemp=gpt_p->c;
					gpt_p->c=pt_p->c;
					pt_p->c=ctemp;
					p=rightrotate(gpt_p);
					if(p->pt==0)
					root=p;
				}
				else {
					char ctemp=gpt_p->c;
					gpt_p->c=p->c;
					p->c=ctemp;
					p=leftrotate(pt_p);
					if(p->pt==0)
					root=p;
					p=rightrotate(gpt_p);
					if(p->pt==0)
					root=p;
				}
			}
		}
		else if(pt_p==gpt_p->right){
			u_p=gpt_p->left;
			if(u_p!=0&&u_p->c=='R') {
				pt_p->c='B';
				u_p->c='B';
				gpt_p->c='R';
				p=gpt_p;
			}
			else {
				if(pt_p->right==p) {
					char ctemp=gpt_p->c;
					gpt_p->c=pt_p->c;
					pt_p->c=ctemp;
					p=leftrotate(gpt_p);
					if(p->pt==0)
					root=p;
				}
				else {
					char ctemp=gpt_p->c;
					gpt_p->c=p->c;
					p->c=ctemp;
					p=rightrotate(pt_p);
					if(p->pt==0)
					root=p;
					p=leftrotate(gpt_p);
					if(p->pt==0)
					root=p;
				}
			}
		}
		
		//printf("%d ",p->data);
	}
	root->c='B';
	return root;
}
void pre(node *root) {
	if(root==0) {
		printf("( ) ");
		return ;
	}
	printf("( %d %c ",root->data,root->c);
	pre(root->left);
	pre(root->right);
	printf(") ");
}

int main() {
	int i,j,k,n;
	node *root=0;
	while(1) {
		char *c=(char *)calloc(7,sizeof(char));
		scanf("%s",c);
		if(c[0]=='t')
	        return 0;
	n=0;
	i=0;
	while(i<strlen(c)) {
		int a=c[i]-'0';
		n+=a;
		n*=10;
		i++;
	}
				k=n/10;
				node *newnode=createnode(k);
				root=bstinsert(root,newnode);
				//root->c='B';
				root=correcting(root,newnode);
				pre(root);
				printf("\n");
				free(c);
			
	}
	return 0;
}











