#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#define maxn 100000
struct node{
	int data;
	int ht;
	struct node *right;
	struct node *left;
};
typedef struct node node;
node* create(int k) {
	node *newnode=(node *)calloc(1,sizeof(node));
	newnode->data=k;
	newnode->left=0;
	newnode->right=0;
	newnode->ht=0;
	return newnode;
}
int max(int a,int b) {
	if(a>b)
	return a;
	return b;
}
int min(int a,int b) {
	if(a<b)
	return a;
	return b;
}
node* min_node(node *root) {
	if(root==0) {
		node *temp=0;
		return temp;
	}
	while(root->left!=0) {
		root=root->left;
	}
	return root;
}
int height(node *root) {
	if(root==0)
	return -1;
	return max(height(root->left),height(root->right))+1;
}
int getbalance(node *root) {
	if(root==0)
	return -1;
	return height(root->left)-height(root->right);
}
node* rotate_left(node *x) {
	node *y=x->right;
	node *temp=y->left;
	y->left=x;
	x->right=temp;
	/*x->ht=1+max(height(x->left),height(x->right));
	y->ht=1+max(height(y->left),height(y->right));*/
	return y;
}
node* rotate_right(node *x) {
	node *y=x->left;
	node *temp=y->right;
	x->left=temp;
	y->right=x;
	/*x->ht=1+max(height(x->left),height(x->right));
	y->ht=1+max(height(y->left),height(y->right));*/
	return y;
}
node* insert(node *root,int k) {
	if(root==0) {
		root=create(k);
		return root;
	}
	if(root->data<k) {
		root->right=insert(root->right,k);
	}
	else if(root->data>k) {
		root->left=insert(root->left,k);
	}
	//root->ht=1+max(height(root->left),height(root->right));
	int balance=getbalance(root);
	//printf("(%d,%d) ",root->data,height(root));
	if(balance>1&&k<root->left->data) {
		return rotate_right(root);
	}
	if(balance>1&&k>root->left->data) {
		root->left=rotate_left(root->left);
		return rotate_right(root);
	}
	if(balance<-1&&k>root->right->data) {
		return rotate_left(root);
	}
	if(balance<-1&&k<root->right->data) {
		root->right=rotate_left(root->right);
		return rotate_right(root);
	}
	return root;
	//printf("(%d,%d) ",root->data,height(root));
}
node* delete_node(node *root,int k) {
	if(root==0) {
		node *temp=0;
		return temp;
	}
	if(root->data>k) {
		root->left=delete_node(root->left,k);
	}
	else if(root->data<k) {
		root->right=delete_node(root->right,k);
	}
	else {
		if(root->left==0) {
			root=root->right;
		}
		else if(root->right==0) {
			root=root->left;
		}
		else {
			node *temp=min_node(root->right);
			root->data=temp->data;
			root->right=delete_node(root->right,temp->data);
		}
	}
	if(root==0)
	return root;
	//root->ht=1+max(height(root->left),height(root->right));
	int balance=getbalance(root);
	//printf("(%d,%d) ",root->data,height(root));
	if(balance>1&&getbalance(root->left)>=0) {
		return rotate_right(root);
	}
	if(balance>1&&getbalance(root->left)<0) {
		root->left=rotate_left(root->left);
		return rotate_right(root);
	}
	if(balance<-1&&getbalance(root->left)<=0) {
		return rotate_left(root);
	}
	if(balance<-1&&getbalance(root->left)>0) {
		root->right=rotate_left(root->right);
		return rotate_right(root);
	}
	return root;
	
}
node* search(node *root,int k) {
	if(root==0)
	return root;
	if(root->data<k) {
		return search(root->right,k);
	}
	else if(root->data>k) {
		return search(root->left,k);
	}
	else {
		return root;
	}
}
void newmode(node *root) {
	if(root==0) {
		printf("( ) ");
		return ;
	}
	printf("( %d ",root->data);
	newmode(root->left);
	newmode(root->right);
	printf(") ");
}
int main() {
	int i,j,k;
	char c;
	node *root=0,*temp;
	while(1) {
		scanf("%c",&c);
		switch(c) {
			case 'i':
			scanf("%d",&k);
			root=insert(root,k);
			break;
			case 'd':
			    scanf("%d",&k);
			    temp=search(root,k);
				if(temp==0) {
					printf("FALSE\n");
				}
				else if(temp->data==k) {
					root=delete_node(root,k);
					printf("%d\n",k);
				}
			break;
			case 's':
				scanf("%d",&k);
				temp=search(root,k);
				if(temp==0) {
					printf("FALSE\n");
				}
				else if(temp->data==k) {
					printf("TRUE\n");
				}
			break;
			case 'b':
				scanf("%d",&k);
				temp=search(root,k);
				if(temp==0) {
					printf("FALSE\n");
				}
				if(temp->data==k) {
					printf("%d\n",getbalance(temp));
				}
			break;
			case 'p':
				newmode(root);
				printf("\n");
			break;
			case 'e':
				return 0;
				
		}
	}
	return 0;
}
