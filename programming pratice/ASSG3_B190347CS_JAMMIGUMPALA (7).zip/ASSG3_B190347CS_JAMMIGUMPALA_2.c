#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#define max 100000

struct node{
int key;
int count; //number of times a key appears in the array
int height;
struct node *left;
struct node *right;
};

typedef struct node node;

node* createnode(int k) {
	node *newnode = (node *)calloc(1,sizeof(node));
	newnode->key=k;
	newnode->count=1;
	newnode->height=1;
	newnode->left=0;
	newnode->right=0;
	return newnode;
}

int maxofnum(int a,int b) {
	return a>b?a:b;
}


int height(node *root) {
	if(root==0)
	return 0;
	return root->height;;
}

node* rightrotate(node *root) {
	node *temp=root->left;
	root->left=temp->right;
	temp->right=root;
	root->height=maxofnum(height(root->left),height(root->right))+1;
	temp->height=maxofnum(height(temp->right),height(temp->left))+1;
	return temp;
}

node* leftrotate(node *root) {
	node *temp=root->right;
	root->right=temp->left;
	temp->left=root;
	root->height=maxofnum(height(root->left),height(root->right))+1;
	temp->height=maxofnum(height(temp->left),height(temp->right))+1;
	return temp;
}

node* insert(node *root,int k) {
	if(root==0) {
		return createnode(k);
	}
	
	if(root->key>k) {
		root->left=insert(root->left,k);
	}
	else if(root->key<k) {
		root->right=insert(root->right,k);
	}
	else {
		root->count++;
		return root;
	}
	
	root->height=maxofnum(height(root->left),height(root->right))+1;
	
	int bal=height(root->left)-height(root->right);
	
	if(bal>1&&k<root->left->key) {
		return rightrotate(root);
	}
	if(bal>1&&root->left->key<k) {
		root->left=leftrotate(root->left);
		return rightrotate(root);
	}
	if(bal<-1&&root->right->key<k) {
		return leftrotate(root);
	}
	if(bal<-1&&root->right->key>k) {
		root->right=rightrotate(root->right);
		return leftrotate(root);
	}
	return root;
}

void preorder(node *root) {
	if(root==0)
	return ;
	preorder(root->left);
	while(root->count-- >0) {
		printf("%d ",root->key);
	}
	preorder(root->right);
}

int main() {
	int i,j,k,n;
	scanf("%d",&n);
	node *root=0;
	int *arr=(int *)calloc(n,sizeof(int));
	for(i=0;i<n;i++) {
		scanf("%d",&k);
		root=insert(root,k);
	}
	preorder(root);
	return 0;
}

























