#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#define max 1000000
#define min -1000000
struct node{
	int data;
	struct node *right;
	struct node *left;
	struct node *p;
};
struct stack {
	char data;
	struct stack *next;
};
typedef struct node node;
typedef struct stack stack;
stack *front=0;
node* create(int k) {
	node *newnode=(node *)calloc(1,sizeof(node));
	newnode->data=k;
	newnode->left=0;
	newnode->right=0;
	return newnode;
}
int checkingbst(node *root,int leftlimit,int rightlimit) {
	if(root==0)
		return 1;
	if(root->data<leftlimit||root->data>rightlimit) {
		return 0;
	}
	return checkingbst(root->left,leftlimit,root->data)&&checkingbst(root->right,root->data,rightlimit);
}
int totalsum(node *root) {
	if(root==0)
		return 0;
	return root->data+totalsum(root->left)+totalsum(root->right);
}
void preorder(node *root,int *count,int k) {
	if(root==0) {
		return  ;
	}
	preorder(root->left,count,k);
	int a=checkingbst(root,min,max);
	if(a==1) {
		int sum=totalsum(root);
		if(sum==k)
			*count=*count+1;
	}
	preorder(root->right,count,k);
}
void push(char c) {
	stack *temp=(stack *)calloc(1,sizeof(stack));
	temp->data=c;
	temp->next=front;
	front=temp;
}
void pop() {
	if(front==0)
	return ;
	stack *temp=front;
	front=front->next;
	free(temp);
}
int indx(char *s,int i,int j) {
	if(i>j)
		return -1;
	int k;
	front=0;
	for(k=i;k<=j;k++) {
		if(s[k]=='(') {
			push(s[k]);
		}
		else if(s[k]==')') {
			pop();
			if(front==0)
				return k;
		}
	}
	return -1;
}
node* convert(char *s,int i,int j) {
	if(i>j) {
		node *temp=0;
		return temp;
	}
	int num=0,a,sign=0;
	while(s[i]!='(') {
		if(s[i]=='-') {
			sign=1;
			i++;
			continue;
		}
		a=s[i]-'0';
		num+=a;
		num*=10;
		i++;
	}
	if(sign==1) {
		num*=-1;
	}
	node *root=create(num/10);
	i--;
	int ind=indx(s,i+1,j);
	if(ind!=-1) {
		root->left=convert(s,i+2,ind-1);
		if(root->left)
			root->left->p=root;
		root->right=convert(s,ind+2,j-1);
		if(root->right)
			root->right->p=root;
	}
	return root;
}
void postorder(node *root) {
	if(root==0) {
		return ;
	}
	postorder(root->left);
	printf("%d ",root->data);
	postorder(root->right);
}
int main() {
	int i=0,j=0,k,n;
	int *count=(int *)calloc(1,sizeof(int));
	char *str=(char *)calloc(max,sizeof(char));
	char *s=(char *)calloc(max,sizeof(char));
	scanf("%[^\n]",str);
	scanf("%d",&k);
	for(i=0;i<strlen(str);i++) {
		if(str[i]!=' ') {
			s[j++]=str[i];
		}
	}
	j=0;
	node *root=convert(s,j+1,strlen(s)-2);
	preorder(root,count,k);
	if(*count==0)
	printf("-1\n");
	else
	printf("%d\n",*count);
	return 0;
}


