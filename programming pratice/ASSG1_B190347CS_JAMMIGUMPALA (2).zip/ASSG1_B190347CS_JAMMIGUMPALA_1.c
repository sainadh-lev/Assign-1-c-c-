#include<stdio.h>
#include<string.h>
#include<stdlib.h>
struct node{
	int data;
	struct node *left;
	struct node *right;
	struct node *p;
};
typedef struct node node;
node *front;
node* create(int k) {
	node *newnode=(node *)calloc(1,sizeof(node));
	newnode->data=k;
	newnode->left=0;
	newnode->right=0;
	newnode->p=0;
	return newnode;
}
void push(node *temp) {
	int i=0;
	if(front==0) {
		front=create(i);
		front->left=temp;
		return ;
	}
	node *temp3=front;
	while(temp3->right!=0) {
		temp3=temp3->right;
	}
	node *temp2=create(i);
	temp2->left=temp;
	temp3->right=temp2;
}
void pop() {
	if(front==0)
	return ;
	node *temp=front;
	front=front->right;
	free(temp);
}
node* insert(node *root,int k) {
	if(root==0) {
		node *newnode=create(k);
		return newnode;
	}
	push(root);
	while(front!=0) {
		node *temp=front;
		if(temp->left->left) {
			push(temp->left->left);
		}
		else {
			temp->left->left=create(k);
			temp->left->left->p=temp->left;
			return root;
		}
		if(temp->left->right) {
			push(temp->left->right);
		}
		else {
			temp->left->right=create(k);
			temp->left->right->p=temp->left;
			return root;
		}
		pop();
	}
	return root;
}
void newmode(node *root) {
	if(root==0) {
		printf("( ) ");
		return;
	}
	printf("( %d ",root->data);
	newmode(root->left);
	newmode(root->right);
	printf(") ");
}
int main() {
	int i,j,k;
	node *root=0;
	char c;
	while(1) {
		scanf("%c",&c);
		if(c=='i') {
			scanf("%d",&k);
			root=insert(root,k);
		}
		if(c=='p') {
			newmode(root);
			printf("\n");
		}
		if(c=='e') {
			return 0;
		}
	}
	
	return 0;
}




















