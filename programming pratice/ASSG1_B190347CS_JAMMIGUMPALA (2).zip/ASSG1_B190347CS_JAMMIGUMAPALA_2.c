#include<stdio.h>
#include<string.h>
#include<stdlib.h>
typedef long long int ll;
#define max 1000000
int maxval(int a,int b) {
	if(a<b)
	return b;
	return a;
}
struct stack{
	char data;
	struct stack *next;
};
struct node{
	int data;
	struct node *left;
	struct node *right;
	struct node *p;
};
typedef struct node node;
typedef struct stack stack; 
stack *top;
int j;
node *front;
node* create(int k) {
	node *newnode=(node *)calloc(1,sizeof(node));
	newnode->data=k;
	newnode->left=0;
	newnode->right=0;
	newnode->p=0;
	return newnode;
}
int queuesize() {
	int i=0;
	node *temp=front;
	while(temp!=0) {
		temp=temp->right;
		i++;
	}
	return i;
}
void pushq(node *temp) {
	int i=0;
	if(front==0) {
		front=create(i);
		front->left=temp;
		return ;
	}
	node *temp3=front;
	while(temp3->right!=0) {
		temp3=temp3->right;
	}
	node *temp2=create(i);
	temp2->left=temp;
	temp3->right=temp2;
}
void popq() {
	if(front==0)
	return ;
	node *temp=front;
	front=front->right;
	free(temp);
}
void push(char c) {
	stack *newnode=(stack *)calloc(1,sizeof(stack));
	newnode->data=c;
	newnode->next=top;
	top=newnode;
	return;
}
void pop() {
	if(top==0)
	return ;
	stack *temp=top;
	top=top->next;
	free(temp);
}
int indx(char *s,int i,int j) {
	if(i>j)
	return -1;
	top=0;
	int k;
	for(k=i;k<=j;k++) {
		if(s[k]=='(') {
			push(s[k]);
		}
		else if(s[k]==')') {
			pop();
			if(top==0)
			return k;
		}
	}
	return -1;
}
node* convert(char *s,int i,int j) {
	if(i>j) {
		node *temp=0;
		return temp;
	}
	int a,num=0,sign=0;
	while(s[i]!='(') {
		if(s[i]=='-') {
			sign=1;
			i++;
			continue;
		}
		a=s[i]-'0';
		num+=a;
		num*=10;
		i++;
	}
	if(sign==1)
	num*=-1;
	node *root=create(num/10);
	i--;
	int ind=indx(s,i+1,j);
	if(ind!=-1) {
		root->left=convert(s,i+2,ind-1);
		if(root->left)
		root->left->p=root;
		root->right=convert(s,ind+2,j-1);
		if(root->right)
		root->right->p=root;
	}
	return root;
}
void newmode(node *root,node *c,int h) {
	if(root==0) {
		return ;
	}
	if(h==0&&root!=0&&c->p!=root->p) {
		printf("%d ",root->data);
		j=1;
	}
	newmode(root->left,c,h-1);
	//printf("%d ",root->data);
    newmode(root->right,c,h-1);
}
int height(node *root) {
	if(root==0) {
		return 0;
	}
	return maxval(height(root->left),height(root->right))+1;
}
int level(node *root,int k,node *knode) {
	if(root==0) {
		return -1;
	}
	int n,level=0;
	front=0;
	pushq(root);
	while(front!=0) {
		node *temp;
		n=queuesize();
		while(n>0) {
			temp=front;
			if(temp->left->left) {
				pushq(temp->left->left);
			}
			if(temp->left->right) {
				pushq(temp->left->right);
			}
			if(temp->left->data==k) {
				knode->p=temp->left;
				return level;
			}
			popq();
			n--;
		}
		level++;
	}
	return -1;
}
int main() {
	int i,k=0,a;
	char str[max];
	char s[max];
	scanf("%[^\n]",str);
	scanf("%d",&a);
    for(i=0;i<strlen(str);i++) {
    	if(str[i]!=' ') {
		 s[k++]=str[i];
	    }
    } 
	i=1;
	node *root=convert(s,i,strlen(s)-2);
	node *temp=create(-123);
	int h=level(root,a,temp);
	if(h!=-1)
	newmode(root,temp->p,h);
	if(j==0||h==-1)
	printf("-1");
	printf("\n");
	return 0;
}

// (1 ( 2 (4 (8 (16()()) (17()())) (9 (18()()) ())) (5 (10()()) (11()()))) (3 (6 (-12()()) (-13()())) (7 (14()()) (15()()))))
// (1 ( 2 (4 (8 (16()()) (17()())) (9 (18()()) (19()()))) (5 (10()()) (11()()))) (3 (6 (12()()) (13()())) (7 (14()()) (15()()))))



