#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#define max 1000000
typedef long long int ll;
struct stack{
	char data;
	struct stack *next;
};
struct node{
	int data;
	struct node *left;
	struct node *right;
	struct node *p;
};
typedef struct stack stack;
typedef struct node node;
stack *top=0;
void push(char c) {
	stack *newnode=(stack *)calloc(1,sizeof(stack));
	newnode->data=c;
	newnode->next=top;
	top=newnode;
}
void pop() {
	if(top==0)
	return ;
	stack *temp=top;
	top=top->next;
	free(temp);
}
node* create(int k) {
	node *newnode=(node *)calloc(1,sizeof(node));
	newnode->data=k;
	newnode->left=0;
	newnode->right=0;
	newnode->p=0;
	return newnode;
}
int indx(char *s,int i,int j) {
	if(i>j)
	return -1;
	int k;
	for(k=i;k<=j;k++) {
		if(s[k]=='(') {
			push(s[k]);
		}
		else if(s[k]==')') {
			pop();
			if(top==0)
			return k;
		}
	}
	return -1;
}
node* convert(char *s,int i,int j) {
	if(i>j) {
		node *temp=0;
		return temp;
	}
	int a=0,num=0,sign=0;
	while(s[i]!='(') {
		if(s[i]=='-') {
			sign=1;
			i++;
			continue;
		}
		a=s[i]-'0';
		num+=a;
		num*=10;
		i++;
	}
	if(sign==1)
	num*=-1;
	node *root=create(num/10);
	i--;
	int ind=indx(s,i+1,j);
	if(ind!=-1) {
		root->left=convert(s,i+2,ind-1);
		if(root->left)
		root->left->p=root;
		root->right=convert(s,ind+2,j-1);
		if(root->right)
		root->right->p=root;
	}
	return root;
}
void kthsmallest(node *root,int *count) {
	if(root==0)
	return ;
	kthsmallest(root->left,count);
	*count=*count-1;
	if(*count==0) {
	    printf("%d\n",root->data);	
	}
	kthsmallest(root->right,count);
}
int main() {
	int i,j=0,k,a=1;
	char *str=(char *)calloc(max,sizeof(char));
	char *s=(char *)calloc(max,sizeof(char));
	scanf("%[^\n]",str);
	scanf("%d",&k);
	for(i=0;i<strlen(str);i++) {
		if(str[i]!=' ') {
			s[j++]=str[i];
		}
	}
	node *root=0;
	root=convert(s,a,strlen(s)-2);	
	int *count;
	count=(int *)calloc(1,sizeof(int));
	*count=k;
	kthsmallest(root,count);
return 0;	
}
