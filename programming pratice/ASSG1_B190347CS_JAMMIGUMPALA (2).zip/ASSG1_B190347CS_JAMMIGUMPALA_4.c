#include<stdio.h>
#include<stdlib.h>
#include<string.h>
struct node{
	int data;
	struct node *left;
	struct node *right;
	struct node *p;
};
struct tree{
	struct node *root;
};
typedef struct tree tree;
typedef struct node node;

node* CreateNode(int k) {
	node *newnode=(node *)calloc(1,sizeof(node));
	newnode->data=k;
	newnode->p=0;
	newnode->left=0;
	newnode->right=0;
	return newnode;
}

node* Insert(node *root,node  *x) {
	if(root==0) {
		return x;
	}
	if(root->data>x->data) {
		root->left=Insert(root->left,x); 
		root->left->p=root;
	}
	else {
		root->right=Insert(root->right,x); 
		root->right->p=root;
	}
	return root;
} 

node* Search(node *root,int k) {
	if(root==0)
	return 0;
	if(root->data==k) {
		return root;
	}
	else if(root->data>k) {
		return Search(root->left,k);
	}
	else {
		return Search(root->right,k);
	}
	return 0;
}

node* transplant(node *root,node *x,node *y) {
	if(x->p==0) {
		root=y;
	}
	else if(x->p->left==x) {
		x->p->left=y;
	}
	else {
		x->p->right=y;
	}
	if(y!=0) {
		y->p=x->p;
	}
	return root;
}
node* minimum(node *root) {
	if(root==0) {
		node *temp=0;
		return temp;
	}
	if(root->left==0) {
		return root;
	}
	return minimum(root->left);
}
int maxval(node *root) {
	if(root==0)
	return -1;
	if(root->right==0)
	return root->data;
	return maxval(root->right);
}
int minval(node *root) {
	if(root==0)
	return -1;
	if(root->left==0)
	return root->data;
	return minval(root->left);
}
node* Delete(node *root,node* x) {
	if(x->left==0) {
		root=transplant(root,x,x->right);
	}
	else if(x->right==0) {
		root=transplant(root,x,x->left);
	} 
	else {
		node *y=minimum(x->right);
		if(x->right!=y) {
			root=transplant(root,y,y->right);
			y->right=x->right;
			y->right->p=y;
		}
		root=transplant(root,x,y);
		y->left=x->left;
		y->left->p=y;
	}
	return root;
}
int predessor(node *root,node *x) {
	if(x==0||root==0)
	return -1;
	if(x->left!=0) {
		return maxval(x->left);
	}
	node *temp=0;
	while(root!=x) {
		if(root->data>x->data) {
			root=root->left;
		}
		if(root->data<x->data) {
			temp=root;
			root=root->right;
		}
	} 
	if(temp==0)
	return -1;
	return temp->data;
}
int successor(node *root,node *x) {
	if(x==0||root==0)
	return -1;
	if(x->right!=0)
	return minval(x->right);
	node *temp=0;
	while(root!=x) {
		if(root->data>x->data) {
			temp=root;
			root=root->left;
		}
		if(root->data<x->data) {
			root=root->right;
		}
	}
	if(temp==0)
	return -1;
	return temp->data; 
}
void inorder(node *root) {
	if(root==0)
	return ;
	
	inorder(root->left);
	printf("%d ",root->data);
	inorder(root->right);
}
void postorder(node *root) {
	if(root==0)
	return ;
	
	postorder(root->left);
	postorder(root->right);
	printf("%d ",root->data);
}
void preorder(node *root) {
	if(root==0)
	return ;
	
	printf("%d ",root->data);
	preorder(root->left);
	preorder(root->right);
}
int level(node *root,int k) {
	int l=1;
	node *temp=root;
	while(temp!=0&&temp->data!=k) {
		if(temp->data>k) {
			l++;
			temp=temp->left;
		}
		if(temp->data<k) {
			l++;
			temp=temp->right;
		}
	}
	if(temp!=0&&temp->data==k)
	return l;
	return -1;
}
int main() {
	int i,j,k,n,a;
	char c;
	tree *t=(tree *)calloc(1,sizeof(tree));
	t->root=0;
	node *x,*y;
	while(1) {
		scanf("%c",&c);
		switch(c) {
			case 'a':
				scanf("%d",&k);
				x=CreateNode(k);
				t->root=Insert(t->root,x);
				break;
			case 'd':
				scanf("%d",&k);
				x=Search(t->root,k);
				if(x!=0)
				t->root=Delete(t->root,x);
				if(x==0)
				printf("-1\n");
				else
				printf("%d\n",x->data);
				break;
			case 's':
				scanf("%d",&k);
				x=Search(t->root,k);
				if(x==0)
				printf("-1\n");
				else
				printf("1\n");
				break;
			case 'l':
				scanf("%d",&k);
				a=level(t->root,k);
				printf("%d\n",a);
				break;
			case 'm':
				a=minval(t->root);
				if(t->root!=0)
				printf("%d\n",a);
				break;
			case 'x':
				a=maxval(t->root);
				if(t->root!=0)
				printf("%d\n",a);
				break;
			case 'r':
				scanf("%d",&k);
				x=Search(t->root,k);
				a=predessor(t->root,x);
				printf("%d\n",a);
				break;
			case 'u':
				scanf("%d",&k);
				x=Search(t->root,k);
				a=successor(t->root,x);
				printf("%d\n",a);
				break;
			case 'i':
				inorder(t->root);
				printf("\n");
				break;
			case 'p':
				preorder(t->root);
				printf("\n");
				break;
			case 't':
				postorder(t->root);
				printf("\n");
				break;
			case 'e':
				return 0;		
		}
	}
}



















