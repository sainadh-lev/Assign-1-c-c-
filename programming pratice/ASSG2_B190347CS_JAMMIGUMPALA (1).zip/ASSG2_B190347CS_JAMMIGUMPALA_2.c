#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#define max 100000
struct node{
	char *word;
	struct node *next;
};
typedef struct node node;
node* create(char *str) {
	node *newnode=(node *)calloc(1,sizeof(node));
	newnode->word=(char *)calloc(500,sizeof(char));
	strcpy(newnode->word,str);
	newnode->next=0;
	return newnode;
}
node* chaining(node *ht,char *str,int k) {
	if(k==0)
	return 0;
	int i,j,l;
	j=strlen(str);
	i=(j*j)%k;
	if(ht[i].word==NULL) {
		ht[i].word=(char *)calloc(500,sizeof(char));
		strcpy(ht[i].word,str);
		return ht;
	}
	node *temp=&(ht[i]);
	if(strcmp(temp->word,str)==0)
		return ht;
	while(temp->next!=0) {
		if(strcmp(temp->word,str)==0) {
			return ht;
		}
		temp=temp->next;
	}
	if(strcmp(temp->word,str)!=0)
	temp->next=create(str);
	return ht;
}
void newmode(node *ht,int k) {
	int i;
	node *temp;
	for(i=0;i<k;i++) {
		temp=&(ht[i]);
		if(temp!=0&&temp->word!=NULL) {
			printf("%d:",i);
			while(temp!=0) {
				printf("%s",temp->word);
				temp=temp->next;
				if(temp!=0)
				printf("-");
			}
		}
		else {
			printf("%d:null",i);
		}
		printf("\n");
	}
	return ;
}
int main() {
	int i,j,k;
	char *str=(char *)calloc(500,sizeof(char));
	scanf("%d\n",&k);
	scanf("%[^\n]",str);
	node *ht=(node *)calloc(k,sizeof(node));
	j=0;
	for(i=0;i<k;i++) {
		ht[i].word=NULL;
	}
	char *s=(char *)calloc(500,sizeof(char));
	for(i=0;i<strlen(str);i++) {
		if(str[i]!=' ') {
			s[j++]=str[i];
		}
		else  {
			j=0;
			ht=chaining(ht,s,k);
			memset(s,'\0',500);
		}
	}
	if(s[0]!='\0')
	ht=chaining(ht,s,k);
	newmode(ht,k);
	return 0;
}
