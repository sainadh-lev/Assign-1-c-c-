#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#define max 100000
struct node{
	int data;
	struct node *right;
	struct node *left;
};
typedef struct node node;
node *front;
node* create(int k) {
	node *newnode=(node *)calloc(1,sizeof(node));
	newnode->data=k;
	newnode->left=0;
	newnode->right=0;
	return newnode;
}
node* convert(int *arr,int l,int r) {
	if(l<=r) {
		int mid=(l+r)/2;
		node *root=create(arr[mid]);
		root->left=convert(arr,l,mid-1);
		root->right=convert(arr,mid+1,r);
		return root;
	}
	node *temp=0;
	return temp;
}
void newmode(node *root) {
	if(root==0) {
		printf("( ) ");
		return  ;
	}
	printf("( %d ",root->data);
	newmode(root->left);
	newmode(root->right);
	printf(") ");
}
int queuesize() {
	int i=0;
	node *temp=front;
	while(temp!=0) {
		temp=temp->right;
		i++;
	}
	return i;
}
void push(node *temp) {
	int i=0;
	if(front==0) {
		front=create(i);
		front->left=temp;
		return ;
	}
	node *temp3=front;
	while(temp3->right!=0) {
		temp3=temp3->right;
	}
	node *temp2=create(i);
	temp2->left=temp;
	temp3->right=temp2;
}
void pop() {
	if(front==0)
	return ;
	node *temp=front;
	front=front->right;
	free(temp);
}
void levelsums(node *root) {
	int n,sum=0;
	if(root==0)
	return ;
	push(root);
	while(front!=0) {
		node *temp;
		n=queuesize();
		sum=0;
		while(n>0) {
			temp=front;
			if(temp->left->left) {
				push(temp->left->left);
			}
			if(temp->left->right) {
				push(temp->left->right);
			}
			n--;
			sum+=temp->left->data;
			pop();
		}
		printf("%d ",sum);
	}
	printf("\n");
}
int main() {
	int i,j,k=0,n;
	scanf("%d",&n);
	int *arr=(int *)calloc(n,sizeof(int));
	for(i=0;i<n;i++) {
		scanf("%d",&arr[i]);
	}
	node *root=0;
	root=convert(arr,k,n-1);
	newmode(root);
	printf("\n");
	levelsums(root);
	return 0;
}


 // (10(2(0(-1()())(1()()))(5(3()())(6()()))(20(15(13()())(16()()))(22(21()())(24()())))))
