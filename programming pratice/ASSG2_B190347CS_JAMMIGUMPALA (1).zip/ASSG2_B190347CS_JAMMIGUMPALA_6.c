#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#define max 100000
struct node{
	int data;
	struct node *right;
	struct node *left;
};
typedef struct node node;
node* create(int k) {
	node *newnode=(node *)calloc(1,sizeof(node));
	newnode->data=k;
	newnode->left=0;
	newnode->right=0;
	return newnode;
}
node* insert(node *root,int k) {
	if(root==0) {
		node *newnode=create(k);
		root=newnode;
		return root;
	}
	if(k<root->data) {
		root->left=insert(root->left,k);
	}
	else {
		root->right=insert(root->right,k);
	}
	return root;
}
void newmode(node *root,int a,int b) {
	if(root==0) {
		return ;
	}
	int i=0;
	node *temp=root;
	while(root!=0) {
		if(root->data==a) {
			i=2;
			break;
		}
		else if(root->data==b) {
			i=3;
			break;
		}
		else if(root->data>a) {
			if(root->data<b) {
				i=1;
				break;
			}
			root=root->left;
		}
		else if(root->data<a) {
			root=root->right;
		}	
	}
	int l=-100000;
	if(i==1||i==2) {
		while(root->data!=b) {
			if(root->data!=b&&root->data!=a) {
				l=l>root->data?l:root->data;
			}
			if(root->data<b) {
				root=root->right;
			}
			else if(root->data>b){
				root=root->left;
			}
		}
	}
	if(i==3) {
		while(root->data!=a) {
			if(root->data!=a&&root->data!=b) {
				l=l>root->data?l:root->data;
			}
			if(root->data<a) {
				root=root->right;
			}
			else if(root->data>a){
				root=root->left;
			}
		}
	}
	printf("%d\n",l);
}
void in(node *root) {
	if(root==0)
	return ;
	in(root->left);
	printf("%d ",root->data);
	in(root->right);
}
int main() {
	int i,a,b,sum,l1,l2;
	char *str=(char *)calloc(max,sizeof(char));
	scanf("%[^\n]",str);
	scanf("%d %d",&a,&b);
	node *root=0;
	for(i=0;i<strlen(str);i++) {
		sum=0;
		while(str[i]!=' '&&i<strlen(str)) {
			int c=str[i]-'0';
			sum+=c;
			sum*=10;
			i++;
		}
		root=insert(root,sum/10);
	}
	l1=a>b?a:b;
	l2=a<b?a:b;
	newmode(root,l2,l1);
	return 0;
}
