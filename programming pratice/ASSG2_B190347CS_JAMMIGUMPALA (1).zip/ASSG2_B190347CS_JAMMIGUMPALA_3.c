#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>

#define max 1000000
struct  node{
	char *word;
	struct node *next;
};
typedef struct node node;
int specialpower(char *str) {
	int *arr=(int *)calloc(8,sizeof(int));
	int i,total=0;
	for(i=0;i<strlen(str);i++) {
		arr[str[i]-'a']++;
	}
	for(i=0;i<8;i++) {
		if(arr[i]>0) {
			total+=pow(2,i);
		}
	}
	return total;
}
node* create(char *str) {
	node *newnode=(node *)calloc(1,sizeof(node));
	newnode->word=(char *)calloc(50,sizeof(char));
	strcpy(newnode->word,str);
	newnode->next=0;
	return newnode;
}
node* insert(node *ht,char *str) {
	int i=specialpower(str);
	if(ht[i].word==NULL) {
		ht[i].word=(char *)calloc(50,sizeof(char));
		strcpy(ht[i].word,str);
		return ht;
	}
	node *temp=&(ht[i]);
	while(temp->next!=0) {
		if(strcmp(temp->word,str)==0)
		return ht;
		temp=temp->next;
	}
	if(strcmp(temp->word,str)!=0)
	temp->next=create(str);
	return ht;
}
void sort(node *temp) {
	int i,j,k;
	node *temp1=temp,*temp3;
	char *str=(char *)calloc(50,sizeof(char));
	while(temp1!=0) {
		node *temp2=temp1->next;
		while(temp2!=0) {
			k=strcmp(temp1->word,temp2->word);
			if(k>0) {
				strcpy(str,temp1->word);
				strcpy(temp1->word,temp2->word);
				strcpy(temp2->word,str);
			}
			temp2=temp2->next;
		}
		temp1=temp1->next;
	}
}
void newmode(node *ht) {
	int i,j,k;
	for(i=0;i<255;i++) {
		if(ht[i].word!=0) {
			node *temp=&(ht[i]);
			sort(&ht[i]);
			while(temp!=0) {
				printf("%s",temp->word);
				temp=temp->next;
				if(temp!=0)
				printf(" ");
			}
			printf("\n");
		}
	}
}
int main() {
	int i,j,k,n;
	scanf("%d",&n);
	node *ht=(node *)calloc(255,sizeof(node));
	for(i=0;i<n;i++) {
		ht[i].word=NULL;
	}
	for(i=0;i<n;i++) {
		char *str=(char *)calloc(50,sizeof(char));
		scanf("%s",str);
		ht=insert(ht,str);
	}
	newmode(ht);
	return 0;
}








