#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#define max 1000000
typedef long long int ll;
struct stack{
	char data;
	struct stack *next;
};
struct node{
	int data;
	struct node *left;
	struct node *right;
	struct node *p;
};
typedef struct stack stack;
typedef struct node node;
stack *top=0;
int fill=0;
void push(char c) {
	stack *newnode=(stack *)calloc(1,sizeof(stack));
	newnode->data=c;
	newnode->next=top;
	top=newnode;
}
void pop() {
	if(top==0)
	return ;
	stack *temp=top;
	top=top->next;
	free(temp);
}
node* create(int k) {
	node *newnode=(node *)calloc(1,sizeof(node));
	newnode->data=k;
	newnode->left=0;
	newnode->right=0;
	newnode->p=0;
	return newnode;
}
int minval(node *root) {
	if(root==0)
	return -1;
	if(root->left==0)
	return root->data;
	return minval(root->left);
}
int maxval(node *root) {
	if(root==0)
	return -1;
	if(root->right==0)
	return root->data;
	return maxval(root->right);
}
int indx(char *s,int i,int j) {
	if(i>j)
	return -1;
	int k;
	for(k=i;k<=j;k++) {
		if(s[k]=='(') {
			push(s[k]);
		}
		else if(s[k]==')') {
			pop();
			if(top==0)
			return k;
		}
	}
	return -1;
}
node* convert(char *s,int i,int j) {
	if(i>j) {
		node *temp=0;
		return temp;
	}
	int a=0,num=0,sign=0;
	while(s[i]!='(') {
		if(s[i]=='-') {
			sign=1;
			i++;
			continue;
		}
		a=s[i]-'0';
		num+=a;
		num*=10;
		i++;
	}
	if(sign==1)
	num*=-1;
	node *root=create(num/10);
	i--;
	int ind=indx(s,i+1,j);
	if(ind!=-1) {
		root->left=convert(s,i+2,ind-1);
		if(root->left)
		root->left->p=root;
		root->right=convert(s,ind+2,j-1);
		if(root->right)
		root->right->p=root;
	}
	return root;
}
node* Search(node *root,int k) {
	if(root==0)
	return 0;
	if(root->data==k) {
		return root;
	}
	else if(root->data>k) {
		return Search(root->left,k);
	}
	else {
		return Search(root->right,k);
	}
	return 0;
}
void kthsmallest(node *root,int *count) {
	if(root==0)
	return ;
	kthsmallest(root->left,count);
	*count=*count-1;
	if(*count==0) {
	    printf("%d\n",root->data);	
	    fill=1;
	}
	kthsmallest(root->right,count);
}
void kthlargest(node *root,int *count) {
	if(root==0) {
		return ;
	}
	kthlargest(root->right,count);
	*count=*count-1;
	if(*count==0) {
		printf("%d\n",root->data);
		fill=1;
	}
	kthlargest(root->left,count);
}
int predessor(node *root,node *x) {
	if(x==0||root==0)
	return -1;
	if(x->left!=0) {
		return maxval(x->left);
	}
	node *temp=0;
	while(root!=x) {
		if(root->data>x->data) {
			root=root->left;
		}
		if(root->data<x->data) {
			temp=root;
			root=root->right;
		}
	} 
	if(temp==0)
	return -1;
	return temp->data;
}
int successor(node *root,node *x) {
	if(x==0||root==0)
	return -1;
	if(x->right!=0)
	return minval(x->right);
	node *temp=0;
	while(root!=x) {
		if(root->data>x->data) {
			temp=root;
			root=root->left;
		}
		if(root->data<x->data) {
			root=root->right;
		}
	}
	if(temp==0)
	return -1;
	return temp->data; 
}
void inorder(node *root) {
	if(root==0)
	return ;
	
	inorder(root->left);
	printf("%d ",root->data);
	inorder(root->right);
}
int main() {
	int i,j=0,k,a=1;
	char *str=(char *)calloc(max,sizeof(char));
	char *s=(char *)calloc(max,sizeof(char));
	scanf("%[^\n]",str);
	for(i=0;i<strlen(str);i++) {
		if(str[i]!=' ') {
			s[j++]=str[i];
		}
	}
	node *root=0;
	root=convert(s,a,strlen(s)-2);	
	int *count;
	count=(int *)calloc(1,sizeof(int));
	node *x;
	char c;
	while(1) {
		scanf("%c",&c);
		switch(c) {
			case 's':
				scanf("%d",&k);
				*count=k;
				fill=0;
				kthsmallest(root,count);
				if(fill==0)
				printf("-1\n");
				break;
			case 'l':
				scanf("%d",&k);
				*count=k;
				fill=0;
				kthlargest(root,count);
				if(fill==0) {
					printf("-1\n");
				}
				break;
			case 'r':
				scanf("%d",&k);
				x=Search(root,k);
				a=predessor(root,x);
				printf("%d\n",a);
				break;
			case 'u':
				scanf("%d",&k);
				x=Search(root,k);
				a=successor(root,x);
				printf("%d\n",a);
				break;
			case 'i':
				inorder(root);
				printf("\n");
				break;
			case 'e':
				return 0;		
		}
	}
return 0;	
}
