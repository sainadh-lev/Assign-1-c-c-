#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#define max 100000
struct node{
	int data;
	int fill;
	struct node *next;
};
typedef struct node node;
int c1,c2,m,r;
char c;
int prime() {
	int i=m-1,j;
	while(i>0) {
		int k=sqrt(i)+1,a=0;
		for(j=2;j<=k;j++) {
			if(i%j==0) {
				a=1;
				break;
			}
		}
		if(a==0)
		return i;
		i--;
	}
	return i;
}
int h1(int k) {
	return k%m;
}
int h2(int k) {
	return r-(k%r);
}
int ha(int k,int i) {
	int j;
	j=(h1(k)+c1*i+c2*i*i)%m;
	return  j;
}
int hb(int k,int i) {
	int j;
	j=h1(k)+i*h2(k);
	return j%m;
}
node* insert(node *ht,int k) {
	int a=k%m,i;
	if(ht[a].fill==0) {
		ht[a].data=k;
		ht[a].fill=1;
		return ht;
	}
	else {
		for(i=0;i<=m-1;i++) {
			if(c=='a') {
				a=ha(k,i);
			}
			if(c=='b') {
				a=hb(k,i);
			}
			if(ht[a].fill==0) {
			ht[a].data=k;
			ht[a].fill=1;
			return ht;
		   }
		}
	}
	return ht;
}
void search(node *ht,int k) {
	int a=k%m,i,b;
	if(ht[a].data==k) {
		printf("1\n");
		return ;
	}
	for(i=0;i<m;i++) {
		if(c=='a') {
			a=ha(k,i);
		}
		if(c=='b') {
			a=hb(k,i);
		}
		if(ht[a].fill==1&&ht[a].data==k) {
			printf("1\n");
			return ;
		}
	}
	printf("-1\n");
	return ;
}
node* delete(node *ht,int k) {
	int a,i;
	a=k%m;
	for(i=0;i<m;i++) {
		if(c=='a') {
			a=ha(k,i);
		}
		if(c=='b') {
			a=hb(k,i);
		}
		if(ht[a].data==k) {
			ht[a].fill=0;
			ht[a].data=0;
			return ht;
		}
	}
	return ht;
}
void newmode(node *ht) {
	int i;
	for(i=0;i<m;i++) {
		if(ht[i].fill!=0)
		printf("%d (%d)\n",i,ht[i].data);
		else
		printf("%d ()\n",i);
	}
}
int main() {
	int i,j,k;
	node *ht;
	char s;
	scanf("%c",&c);
		scanf("%d",&m);
		if(c=='a')
		scanf("%d %d",&c1,&c2);
		if(c=='b')
		r=prime();
		ht=(node *)calloc(m,sizeof(node));
		for(i=0;i<m;i++) {
			ht[i].fill=0;
		}
		while(1) {
			scanf("%c",&s);
			switch(s) {
				case 'i':
					scanf("%d",&k);
					ht=insert(ht,k);
				break;
				case 'd':
					scanf("%d",&k);
					ht=delete(ht,k);
				break;
				case 'p':
					newmode(ht);
				break;
				case 's':
					scanf("%d",&k);
					search(ht,k);
				break;
				case 't':
					return 0;
			}
		}
	return 0;
}
