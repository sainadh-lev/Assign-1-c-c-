#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#define max 100000
int z;
struct node{
	int data;
	int deg;
	int visited;
	int mark;
	struct node *p;
	struct node *left;
	struct node *right;
	struct node *child;
};

struct heap{
	struct node *min;
	int n;
	int deg;
};

typedef struct node node;
typedef struct heap heap;

heap* createheap() {
	heap *newheap=(heap *)calloc(1,sizeof(heap));
	newheap->min=NULL;
	newheap->deg=0;
	newheap->n=0;
	return newheap;
}

void insert(heap *h,int k) {
	node *newnode=(node *)calloc(1,sizeof(node));
	newnode->data=k;
	newnode->left=newnode;
	newnode->right=newnode;
	newnode->deg=0;
	newnode->mark=0;
	newnode->visited=0;
	newnode->p=0;
	newnode->child=0;
	if(h->min==0) {
		h->min=newnode;
	}
	else {
		newnode->left=h->min->left;
		newnode->right=h->min;
		h->min->left->right=newnode;
		h->min->left=newnode;
		if(h->min->data>newnode->data) {
			h->min=newnode;
		}
	}
	h->n++;
}



int arraysize(int n) {
	int i=0;
	while(n>0) {
		n=n/2;
		i++;
	}
	return i;
}

void fiblink(heap *h,node *a,node *b) {
	b->left->right=b->right;
	b->right->left=b->left;
	if(a->left==a) {
		h->min=a;
	}
	b->left=b;
	b->right=b;
	b->p=a;
	if(a->child==0) {
		a->child=b;
	}
	b->right=a->child;
	b->left=a->child->left;
	a->child->left->right=b;
	a->child->left=b;
	if(a->child->data>b->data)
	a->child=b;
	a->deg++;
}

void consolidate(heap *h) {
	int n=arraysize(h->n),i;
	node *arr[n];
	node *x;
	node *y;
	for(i=0;i<=n;i++) {
		arr[i]=0;
	}
	x=h->min;
	do {
		int d=x->deg;
		while(arr[d]!=0) {
			y=arr[d];
			if(y->data<x->data) {
				node *temp=x;
				x=y;
				y=temp;
			}
			if(y==h->min) {
				h->min=x;
			}
			fiblink(h,x,y);
			arr[d]=0;
			d++;
		}
		arr[d]=x;
		x=x->right;
	}while(x!=h->min);
	
	h->min=0;
	
	for(i=0;i<=n;i++) {
		if(arr[i]!=0) {
			arr[i]->left=arr[i];
			arr[i]->right=arr[i];
			if(h->min==0) {
				h->min=arr[i];
			}
			else {
				arr[i]->right=h->min;
				arr[i]->left=h->min->left;
				h->min->left->right=arr[i];
				h->min->left=arr[i];
				if(arr[i]->data<h->min->data) {
					h->min=arr[i];
				}
			}
		}
	}
	
}




void extractmin(heap *h) {
	if(h==0)
	return ;
	node *temp1=h->min;
	node *temp2=h->min->left;
	node *temp3=h->min->right;
	node *x=h->min->child;
	node *temp4;
	if(h->min->left==h->min&&x==0) {
		h->min=0;
		return ;
	}
	else if(h->min->left==h->min&&h->min->child!=0) {
		if(x!=0) {
			temp4=x;
		do{
			temp4->p=0;
			temp4=temp4->right;
		}while(temp4!=x);
		h->min=x;
		}
		consolidate(h);
		h->n--;
		//printf("%d\n",temp1->data);
		return ;
	}
	else if((h->min->left!=h->min&&h->min->child!=0)){
		temp4=x;
		do{
			temp4->p=0;
			temp4=temp4->right;
		}while(temp4!=x);
		h->min=x;
		node *y=x->left;
		x->left=temp2;
		temp2->right=x;
		y->right=temp3;
		temp3->left=y;
		h->min=temp3;
		consolidate(h);
		h->n--;
		//printf("%d\n",temp1->data);
		return ;
    }
    if(x==0) {
    	h->min->left->right=h->min->right;
    	h->min->right->left=h->min->left;
    	h->min=h->min->right;
    	h->n--;
    	consolidate(h);
    	//printf("%d\n",temp1->data);
		return ;
	}
}


void cut_1(heap *h,node *dec) {
	node *p_dec=dec->p;
	if(p_dec!=0&&dec->right==dec){
		p_dec->child=0;
	}
	dec->right->left=dec->left;
	dec->left->right=dec->right;
	if(p_dec->child!=0) {
		p_dec->child=dec->right;
	}
	p_dec->deg-=1;
	dec->right=dec;
	dec->left=dec;
	dec->right=h->min;
	dec->left=h->min->left;
	h->min->left->right=dec;
	h->min->left=dec;
//	if(dec->data<h->min->data){
//		h->min=dec;
//	}
	dec->mark=0;
	dec->p=0;
}

void cut_2(heap *h,node *p_dec) {
	node *p_p_dec=p_dec->p;
	if(p_p_dec!=0) {
		if(p_dec->mark==0) {
			p_dec->mark=1;
		}
		else {
			cut_1(h,p_dec);
			cut_2(h,p_p_dec);
		}
	}
}

void decreasekey(heap *h,node *dec,int k) {
	dec->data=k;
	node *p_dec=dec->p;
	if(p_dec!=0&&dec->data<p_dec->data) {
		cut_1(h,dec);
		cut_2(h,p_dec);
	}
	if(dec->data<h->min->data){
		h->min=dec;
	}
}

void findnode(heap *h,node *root,int k,int l) {
	if(h->min==0)
	return ;
	root->visited=1;
	if(root->data==k) {
		z=1;
		decreasekey(h,root,l);
	}
	if(root->child&&root->child->visited==0)
	findnode(h,root->child,k,l);
	if(root->right&&root->right->visited==0)
	findnode(h,root->right,k,l);
	root->visited=0;
}



void printer(node *h) {
	if(h==0)
	return ;
	h->visited=1;
	printf("%d",h->data);
//	if(h->p!=0) {
//		printf("(%d)",h->p->data);
//	}
	printf(" ");
//	if(h->child&&h->child->visited==0) {
//		printer(h->child);
//	}
	if(h->right&&h->right->visited==0) {
		printer(h->right);
	}
	h->visited=0;
}

int main() {
	int i,j,k;
	node *temp;
	heap *h=0;
	char c;
	while(1) {
		scanf("%c",&c);
		switch(c) {
			case 'i':
				if(h==0) {
					h=createheap();
				}
				scanf("%d",&k);
				insert(h,k);
				//printer(h->min);
				//printf("\n");
				break;
			case 'm':
				if(h!=0&&h->min!=NULL) {
					printf("%d\n",h->min->data);
				}
				break;
			case 'x':
				if(h->min!=NULL) {
					printf("%d\n",h->min->data);
					extractmin(h);
				}
				break;
			case 'r':
				scanf("%d %d",&k,&i);
				if(k>=i)
				findnode(h,h->min,k,i);
				if(z==1) {
					printf("%d\n",i);
					z=0;
				}
				break;
			case 'd':
				scanf("%d",&k);
				i=-max;
				if(h!=0)
				findnode(h,h->min,k,i);
				if(z==1) {
					extractmin(h);
					printf("%d\n",k);
					z=0;
				}
				break;
			case 'p':
				printer(h->min);
				printf("\n");
				break;
			case 'e':
				return 0;
		}
	}
	
}

