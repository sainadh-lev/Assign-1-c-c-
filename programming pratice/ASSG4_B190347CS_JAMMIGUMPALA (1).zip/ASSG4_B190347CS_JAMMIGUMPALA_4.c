#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#define max 100000

struct node{
	int n;
	struct node *next;
};

struct graph{
	int n;
	int visited;
};

typedef struct node node;
node *q=0;
void push(int k) {
	node *newnode=(node *)calloc(1,sizeof(node));
	newnode->n=k;
	newnode->next=0;
	if(q==0) {
		q=newnode;
		return ;
	}
	node *temp=q;
	while(temp->next!=0) {
		temp=temp->next;
	}
	temp->next=newnode;
}

void pop() {
	if(q==0)
	return ;
	node *temp=q;
	q=q->next;
	free(temp);
}

void bfs(int n,int arr[][n],int m[],int src) {
	int i,j;
	push(src);
	while(q!=0) {
		int k=q->n;
		for(i=0;i<n;i++) {
			if(arr[k][i]>0&&m[i]==0) {
				push(i);
				m[i]=1;
			}
		}
		m[k]=1;
		printf("%d ",k);
		pop();
	}
}

void dfs(int n,int arr[][n],int *m,int src) {
	int i;
	m[src]=1;
	printf("%d ",src);
	for(i=0;i<n;i++) {
		if(arr[src][i]>0&&m[i]==0) {
			dfs(n,arr,m,i);
		}
	}
}

int main() {
	int i,j,k,n,m,l,src;
	scanf("%d %d",&n,&m);
	int arr[n][n];
	int mark[n];
	for(i=0;i<n;i++) {
		for(j=0;j<n;j++) {
			arr[i][j]=0;
		}
		mark[i]=0;
	}
	for(i=0;i<m;i++) {
		scanf("%d %d",&l,&k);
		arr[l][k]=1;
	}
	scanf("%d",&src);
	bfs(n,arr,mark,src);
	printf("\n");
	for(i=0;i<n;i++)
	mark[i]=0;
	dfs(n,arr,mark,src);
	printf("\n");
//	for(i=0;i<n;i++) {
//		for(j=0;j<n;j++) {
//			printf("%d ",arr[i][j]);
//		}
//		printf("\n");
//	}
	return 0;
}

/*
8 16
0 3
0 4
1 6
2 4
3 1
3 5
3 7
4 2
5 1
5 3
5 6
5 7
6 2
6 4
6 5
7 6
*/
