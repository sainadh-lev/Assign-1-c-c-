#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#define max 10000
int q;
struct node{
	int i;
	int rank;
	struct node *p;
};

struct disjoint_set{
	struct node *set;
};

typedef struct node node;
typedef struct disjoint_set sets;
int a,b,e,d;
char z;
sets* makesets() {
	sets *new=(sets *)calloc(max,sizeof(sets));
	int i;
	for(i=0;i<max;i++) {
		new[i].set=0;
	}
	return new;
}

void makeset(sets *s,int k) {
	node *newnode=(node *)calloc(1,sizeof(node));
	newnode->i=k;
	newnode->p=newnode;
	newnode->rank=0;
	if(s[k].set==0) {
		s[k].set=newnode;
	}
	else {
	   q=-1;
	}
}




node* findset_c(node *s) {
	if(s==0)
	return s;
	if(z=='e')
	e++;
	if(z=='d')
	d++;
	if(s->p==s) {
    	return s;
	}
	else {
		s->p=findset_c(s->p);
		return s->p;
	}
}

node* findset(sets *s,int k) {
	node *temp=s[k].set;
	if(temp==0)
	return temp;
	if(temp->p==temp) {
		if(z=='a')
		a++;
		if(z=='b')
		b++;
		return temp;
	}
	else {
		while(temp->p!=temp) {
			if(z=='a')
			a++;
			if(z=='b')
			b++;
			temp=temp->p;
		}
		if(z=='a')
		a++;
		if(z=='b')
		b++;
		return temp;
	}
}

void union_of_sets_a(sets *s,int i,int j) {
	if(i==j)
	return ;
	node *temp1=findset(s,i);
	node *temp2=findset(s,j);
	temp2->p=temp1;
	printf("%d ",temp1->i);
}

void union_of_sets_b(sets *s,int i,int j) {
	if(i==j)
	return ;
	node *temp1,*temp2;
	if(z=='b') {
		temp1=findset(s,i);
	    temp2=findset(s,j);
	}
	if(z=='d') {
		temp1=findset_c(s[i].set);
    	temp2=findset_c(s[j].set);
	}
	if(temp1->rank>temp2->rank) {
		temp2->p=temp1;
		printf("%d ",temp1->i);
	}
	else if(temp1->rank<temp2->rank) {
		temp1->p=temp2;
		printf("%d ",temp2->i);
	}
	else {
		temp2->p=temp1;
		printf("%d ",temp1->i);
		temp1->rank++;
	}
}

void union_of_sets_c(sets *s,int i,int j) {
	if(i==j)
	return ;
	node *temp1=findset_c(s[i].set);
	node *temp2=findset_c(s[j].set);
	temp2->p=temp1;
	printf("%d ",temp1->i);
}




int main() {
	int i,j,k;
	sets *sa=makesets();
	sets *sb=makesets();
	sets *sc=makesets();
	sets *sd=makesets();
	node *temp1,*temp2,*temp3,*temp4;
	char c;
	while(1) {
		scanf("%c",&c);
		switch(c) {
			case 'm':
				scanf("%d",&k);
				makeset(sa,k);
				makeset(sb,k);
				makeset(sc,k);
				makeset(sd,k);
				if(q==-1) {
					q=0;
					printf("-1\n");
				}
				else 
				printf("%d\n",k);
			break;
			case 'f':
				scanf("%d",&k);
				z='a';
				temp1=findset(sa,k);
				z='b';
				temp2=findset(sb,k);
				z='e';
				temp3=findset_c(sc[k].set);
				z='d';
				temp4=findset_c(sd[k].set);
				if(temp1==0) {
					printf("-1\n");
				}
				else {
					printf("%d %d %d %d\n",temp1->i,temp2->i,temp3->i,temp4->i);
				}
			break;
			case 'u':
				scanf("%d %d",&i,&j);
				z='a';
				union_of_sets_a(sa,i,j);
				z='b';
				union_of_sets_b(sb,i,j);
				z='e';
				union_of_sets_c(sc,i,j);
				z='d';
				union_of_sets_b(sd,i,j);
				printf("\n");
				break;
			case 's':
				printf("%d %d %d %d\n",a,b,e,d);
			case 'e':
				return 0;
		}
	}
	
	return 0;
}
