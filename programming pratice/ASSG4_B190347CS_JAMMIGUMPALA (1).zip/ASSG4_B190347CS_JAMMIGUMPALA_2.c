#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#define max 10000
int q;
struct node{
	int s;
	int d;
	int w;
};

struct graph{
	int v;
	struct node *h;
};

struct dis{
	int p;
	int r;
};

typedef struct node node;
typedef struct graph graph;
typedef struct dis dis;

int findset(dis *s,int i) {
	if(s[i].p==i) {
		return i;
	}
	return findset(s,s[i].p);
}

void union_of(dis *s,int i,int j) {
	if(s[i].r>s[j].r) {
		s[j].p=i;
	}
	else if(s[i].r<s[j].r) {
		s[i].p=j;
	}
	else {
		s[j].p=i;
		s[i].r++;
	}
}

graph* makesets(int e) {
	graph *new=(graph *)calloc(1,sizeof(graph));
	int i;
	new->v=e;
	new->h=(node *)calloc(e,sizeof(node));
	return new;
}

void sort(graph *g,int e) {
	node *h=g->h;
	int i,j,k;
	for(i=0;i<e;i++) {
		for(j=i;j<e;j++) {
			if(h[i].w>h[j].w) {
				node temp=h[i];
				h[i]=h[j];
				h[j]=temp;
			}
		}
	}
}

void mst(graph *g,int e) {
	if(g==0)
	return ;
	sort(g,e);
	int i=0,j=0,w=0;
	dis *sets=(dis *)calloc(e,sizeof(dis));
	for(i=0;i<e;i++) {
		sets[i].p=i;
		sets[i].r=0;
	}
	i=0;
	while(i<g->v-1&&j<e) {
		int a=findset(sets,g->h[j].s);
		int b=findset(sets,g->h[j].d);
		if(a==b) {
			j++;
			continue;
		}
		union_of(sets,a,b);
		i++;
		w+=g->h[j].w;
	}
	printf("%d\n",w);
}

int findminvertex(int n,int arr[][n],int *s,int *dist,int u,int *par) {
	int i;
	int min=max;
	int v;
	for(i=0;i<n;i++) {
		if((arr[u][i]!=-max/2)&&s[i]==0&&arr[u][i]<=dist[i]) {
			dist[i]=arr[u][i];
			par[i]=u;
		}
	}
	s[u]=1;
	for(i=0;i<n;i++) {
		if(s[i]==0&&dist[i]<min) {
			min=dist[i];
			v=i;
		}
	}
	return v;
}

void mst_2(int n,int arr[][n]) {
	int par[n];
	int dist[n];
	int s[n];
	int i,j,k,w=0;
	for(i=0;i<n;i++) {
		par[i]=-1;
		dist[i]=max;
		s[i]=0;
	}
	dist[0]=0;
	int src=0,u;
	for(i=0;i<n;i++) {
		s[src]=1;
		src=findminvertex(n,arr,s,dist,src,par);
	}
	for(i=0;i<n;i++) {
		w+=dist[i];
	}
	printf("%d\n",w);
}


int main() {
	int n,i,j,k,e,s,d,w,l,v=0;
	char c;
	scanf("%c",&c);
	scanf("%d",&e);
	char str[e];
	int arr[e][e];
	for(i=0;i<e;i++) {
		for(j=0;j<e;j++) {
			arr[i][j]=-max/2;
		}
	}
	k=0;
	for(i=0;i<=e;i++) {
		gets(str);
		for(j=0;j<strlen(str);j++) {
			int a=0;
			n=0;
			while(str[j]!=' '&&j<strlen(str)) {
				if(j==0) {
					k=1;
				}
				a=str[j]-'0';
				n+=a;
				n*=10;
				j++;
			}
			n/=10;
			if(k==1) {
			l=n;
			k=0;	
			}
			else {
				arr[l][n]=-max;
			}	
		}
		memset(str,'\n',e);
	}
	for(i=0;i<e;i++) {
		gets(str);
		for(j=0;j<strlen(str);j++) {
			int a=0;
			n=0;
			while(str[j]!=' '&&j<strlen(str)) {
				if(j==0) {
					k=1;
				}
				a=str[j]-'0';
				n+=a;
				n*=10;
				j++;
			}
			n/=10;
			if(k==1) {
			l=n;
			k=0;	
			}
			else {
				int z=0;
				for(z=0;z<e;z++) {
					if(arr[l][z]==-max) {
						arr[l][z]=n;
						break;
					}
				}
			}	
		}
		memset(str,'\n',e);
    }
    for(i=0;i<e;i++) {
    	for(j=0;j<e;j++) {
    		if(arr[i][j]!=-max/2) {
    			v++;
			}
		}
	}
	graph *g=makesets(v);
	k=0;
	for(i=0;i<e;i++) {
		for(j=0;j<e;j++) {
			//printf("%d ",arr[i][j]);
			if(arr[i][j]!=-max/2) {
				g->h[k].s=i;
				g->h[k].d=j;
				g->h[k].w=arr[i][j];
				//printf("%d %d %d\n",i,j,arr[i][j]);
				k++;
			}
		}
		//printf("\n");
	}
	if(c=='a')
	mst(g,v);
	if(c=='b')
	mst_2(e,arr);
	return 0;
}


/*
6
0 1 2
1 0 2 3 4
2 0 1 3
3 1 2 4 5
4 1 3 5
5 3 4
0 4 6
1 4 6 3 4
2 6 6 1
3 3 1 2 3
4 4 2 7
5 3 7
*/


/*
7
0 1 5
1 0 2 6
2 1 3
3 2 4 6
4 3 5 6
5 0 4
6 1 3 4
0 28 10
1 28 16 14
2 16 12
3 12 22 18
4 22 25 24
5 10 25
6 14 18 24
*/
