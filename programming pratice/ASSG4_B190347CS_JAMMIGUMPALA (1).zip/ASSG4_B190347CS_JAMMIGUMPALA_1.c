#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
#define max 100000

struct adj_node{
	int num;
	struct adj_node *next;
};

struct graph{
	int n;
	struct adj_node *arr;
};

typedef struct adj_node node;
typedef struct graph graph;

node* create_node(int k) {
	node *newnode=(node *)calloc(1,sizeof(node));
	newnode->num=k;
	newnode->next=0;
	return newnode;
}

graph* create_graph(int n) {
	graph *newnode=(graph *)calloc(1,sizeof(graph));
	newnode->n=n;
	newnode->arr=(node *)calloc(n,sizeof(node));
	int i;
	for(i=0;i<n;i++) {
		newnode->arr[i].num=-1;
	}
	return newnode;
}

void insert(graph *g,int dest,int src) {
	node *arr=g->arr;
	if(arr[src].num==-1) {
		arr[src].num=dest;
		return ;
	}
	node *newnode=create_node(dest);
	node *temp=&arr[src];
	while(temp->next!=0) {
		temp=temp->next;
	}
	temp->next=newnode;
}

void newmode(graph *g) {
	if(g==0)
	return ;
	int i,n;
	n=g->n;
	node *arr=g->arr;
	for(i=0;i<n;i++) {
		printf("%d ",i);
		if(arr[i].num!=-1) {
			node *temp=&arr[i];
			while(temp!=0) {
				printf("%d ",temp->num);
				temp=temp->next;
			}
		}
		printf("\n");
	}
}


int main() {
	int i,j,k,n;
	graph *g=0;
	char c;
	scanf("%d",&n);
	g=create_graph(n);
	int arr[n][n];
	for(i=0;i<n;i++) {
		for(j=0;j<n;j++) {
			scanf("%d",&k);
			if(k>0)
			insert(g,j,i);
		}
	}
	newmode(g);
	return 0;
}
